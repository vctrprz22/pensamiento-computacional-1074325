﻿ Console.WriteLine("Bienvenido a THE PABLI GAME");
        Console.WriteLine("Un juego desarrollado por Bryan Marroquín y Victor Pérez");
        Console.WriteLine("----------------------------------");

        Console.Write("Ingresa tu nombre: ");
        string nombre = Console.ReadLine();
        Console.WriteLine($"\nHola {nombre}, estás atrapado en una isla desierta.");
        Console.WriteLine("Debes sobrevivir 10 días manejando tus recursos. ¡Buena suerte!\n");

        Random rand = new Random();

        // Recursos iniciales
        int energia = rand.Next(60, 76);// valor aleatorio de la energia entre 60 y 75
        int comida = rand.Next(25, 31);// valor aleatorio de la comida entre 25 y 31
        int agua = rand.Next(20, 31);// valor aleatorio del agua entre 20 y 31
        int botellas = 1;//Cantidad inicial de botellas con la que inicia el jugador
        int dia = 1;// contador de los dias
        int probEventoNocturno = 10; // Probabilidad base de evento nocturno

        /* Ciclo principal del juego, esta hecho con while para evaluar las condiciones
        de sobreviri 10 dias o perder por la falta de eneriga */
        while (dia <= 10 && energia > 0)
        {
            Console.WriteLine($"\n--- Día {dia} ---");// imprime el dia actual en el que se encuentra el jugador
            Console.WriteLine($"Energía: {energia} | Comida: {comida} | Agua: {agua} | Botellas: {botellas}");
            Console.WriteLine("Elige la acción:");
            Console.WriteLine("1. Buscar Comida");
            Console.WriteLine("2. Buscar Agua");
            Console.WriteLine("3. Descansar");
            Console.WriteLine("4. Explorar Isla");
            Console.Write("Opción: ");
            /* se le muetran las opciones que puede elegir el jugador , y se deja el espacio de opcion solo en .write para que quede escrito 
            para que el jugador sepa donde colocar la opcion y se vea ordenado*/
            string eleccion = Console.ReadLine();

            switch (eleccion)
            {
                case "1": // Buscar comida
                    int energiaGasto1 = rand.Next(5, 16);// al elegir el case 1 se le restara un valor aleatorio ded energia entre 5 y 16
                    energia -= energiaGasto1;
                    int pfc = rand.Next(0, 100);// genera un numero aleatorio del 1 al 100
                    if (pfc < 30)// significa que hay un 30% que esta condicion sea verdadera
                    {
                        comida += 30;
                        Console.WriteLine("¡Encontraste peces! +30 comida");
                    }
                    else if (pfc < 80)// este tiene un 50% de probabilidad ya que utiliza el valor el arriba , por lo cual del 80% al 30% hay un 50% de probabilidad que suceda
                    {
                        comida += 25;
                        Console.WriteLine("¡Encontraste frutas! +25 comida");
                    }
                    else
                    {// aca ya no es necesario declaralo ya que sabe que el valor restante que queda es la probavilida de este caso , por ende el 20%
                        comida += 10;
                        Console.WriteLine("¡Encontraste semillas! +10 comida");
                    }
                    break;

                case "2": // Buscar agua
                    int energiaGasto2 = rand.Next(10, 21);
                    energia -= energiaGasto2;// se le restara a la energia un valor entre 10 y 21 por realizar esta accion
                    int apac = rand.Next(0, 100);
                    if (apac < 80)// al igual que el caso 1 m este va tener un 80% de probabilidad que suceda esta accion
                    {
                        agua += botellas * 20;// al suceder esto , por cada botella de agua que contenga el jugador se le sumaran por 20 puntos de agua
                        Console.WriteLine($"¡Encontraste agua potable! +{botellas * 20} agua");
                    }
                    else
                    {
                        energia -= 10;// aca tampoco es necesario declalrar ya que el resto que seria 20% sera solo para esta variable 
                        Console.WriteLine("¡El agua estaba contaminada! -10 energía");
                    }
                    break;

                case "3": // Descansar
                    energia += 20;
                    probEventoNocturno += 10; // Aumenta la probabilidad de evento nocturno
                    Console.WriteLine("Descansaste bien. +20 energía");
                    Console.WriteLine("Al descansar, estás más expuesto por la noche. La probabilidad de evento nocturno ha aumentado.");
                    break;

                case "4": // Explorar isla
                    int evento = rand.Next(0, 100);
                    if (evento < 30)// ya mencionada, esto es un 30% de probabilidades 
                    {
                        energia -= 10;
                        Console.WriteLine("¡Fuiste atacado por animales salvajes! -10 energía");
                    }
                    else if (evento < 50)// al ser este un valor de 50 y el anteriori uno de 30 , por lo tanto el valor real que suceda este caso es de 20%
                    {
                        energia -= 20;
                        Console.WriteLine("¡Tuviste un accidente en terrenos peligrosos! -20 energía");
                    }
                    else
                    {// el 50% restante sera la probabilidad de encontrar las botellas de agua 
                        botellas++;
                        Console.WriteLine("¡Encontraste una botella! +1 botella");
                    }
                    break;

                default:// al no colocar una opcion valida el jugador tendra que colocar una opcion correcta para podes seguir 
                    Console.WriteLine("Opción no válida. Intenta de nuevo.");
                    continue; // Vuelve al menú del día sin avanzar de día
            }

            // Consumo de comida
            if (comida >= 20)
                comida -= 20;
            else
            {
                energia -= (20 - comida);
                comida = 0;
            }

            // Consumo de agua
            if (agua >= 15)
                agua -= 15;
            else
            {
                energia -= (15 - agua);
                agua = 0;
            }

            // Evento nocturno (con probabilidad modificada si descansó)
            if (rand.Next(0, 100) < probEventoNocturno)
            {
                int eventoNocturno = rand.Next(1, 4);// aca se indica que porcentaje hay de la probabilidad nocturna , si no se selecciona descansar solo estara el 10% y si si se selecciona habra un 20% de probabilidades
                switch (eventoNocturno)
                {// aca no se colocan como el anteorior ya que al estar en una misma variable,y al indicar que solo son eso 3 , tendran la mis aprbabilidad de suceres del 33.33%
                    case 1:
                        agua += botellas * 10; // si sucede la lluvia , el agua del jugador aumentara 10 puntos por cada bootella que contenga
                        Console.WriteLine("¡Lluvia nocturna! +10 agua por botella");
                        break;
                    case 2:
                        comida = Math.Max(0, comida - 10);/* esto es para restar la comida, pero no quiero que sea menor que 0 por lo tanto 
                        Si comida - 10 da un número mayor que 0, se guarda ese valor. y Si comida - 10 da un número menor que 0, entonces se guarda el 0.*/
                        Console.WriteLine("¡Animales salvajes comieron tu comida! -10 comida");
                        break;
                    case 3:
                        energia -= 10;// la anergia del jugador se restara 10 puntos
                        Console.WriteLine("¡Clima frío nocturno! -10 energía");
                        break;
                }
            }

            // Mostrar estado final del día
            Console.WriteLine($"Fin del día {dia}: Energía={energia}, Comida={comida}, Agua={agua}, Botellas={botellas}");

            dia++;
            probEventoNocturno = 10; // Se reinicia la probabilidad nocturna al valor base
        }

        // Resultado final del juego
        if (energia <= 0)
        { //mensaje de derrota
            Console.WriteLine($"\nTe quedaste sin energía. GAME OVER, {nombre}.");
        }
        else
        {// mensaje de victoria
            Console.WriteLine($"\n¡Felicidades {nombre}! ¡Sobreviviste los 10 días en la isla!");
        }
    
