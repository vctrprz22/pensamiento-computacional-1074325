﻿/*int numero;

do
{
Console.WriteLine("ingrese un numero");
numero = Convert.ToInt32(Console.ReadLine());

if ( numero > 0 )
{
    Console.WriteLine("Su numero multilplicado por 1 es " + (numero * 1));
    Console.WriteLine("Su numero multilplicado por 2 es " + (numero * 2));
    Console.WriteLine("Su numero multilplicado por 3 es " + (numero * 3));
    Console.WriteLine("Su numero multilplicado por 4 es " + (numero * 4));
    Console.WriteLine("Su numero multilplicado por 5 es " + (numero * 5));
    Console.WriteLine("Su numero multilplicado por 6 es " + (numero * 6));
    Console.WriteLine("Su numero multilplicado por 7 es " + (numero * 7));
    Console.WriteLine("Su numero multilplicado por 8 es " + (numero * 8));
    Console.WriteLine("Su numero multilplicado por 9 es " + (numero * 9));
    Console.WriteLine("Su numero multilplicado por 10 es " + (numero * 10));
    
}
else
{
    Console.WriteLine("Numero incorrecto, ingrese de nuevo su numero");
}
}while (numero < 0);
*/

int numero;
int multiplicacion = 0;
do
{
Console.WriteLine("Ingrese un numero");
numero = Convert.ToInt32(Console.ReadLine());
if (numero > 0)
{

    for (int actual = 1; actual <=10; actual ++)

    {
    multiplicacion = numero * actual;
    Console.WriteLine("El numero " + numero + " multiplicado por " + actual + " es " + multiplicacion);
    }
}
else
{
    Console.WriteLine("Numero incorrecto, ingrese de nuevo su numero");
}
}while (numero <0);

