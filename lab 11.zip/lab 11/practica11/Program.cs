﻿Console.WriteLine("Ingresa un texto:");
        string texto = Console.ReadLine();
        
        string[] palabras = texto.Split(' '); //esto lo busque yo , y me sirve para divdir palabras , ene ste caso por espacios
        int cantidadPalabras = 0;
        
        for (int i = 0; i < palabras.Length; i++)
        {
            if (palabras[i] != "") 
            {
                cantidadPalabras++;
            }
        }
        Console.WriteLine("Cantidad de palabras ingresadas: " + cantidadPalabras);
        
       
        string resultado = "";
        for (int i = 0; i < palabras.Length; i++)
        {
            if (palabras[i] != "")
            {
                string primeraLetra = palabras[i].Substring(0, 1).ToUpper();
                string restoPalabra = palabras[i].Substring(1).ToLower();
                resultado += primeraLetra + restoPalabra + " ";
            }
        }
        
        Console.WriteLine("Texto con cada palabra en mayúscula: " + resultado.Trim());
    