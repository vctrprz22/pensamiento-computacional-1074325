﻿int numero;

do
{
    Console.WriteLine("Ingrese su edad");
    numero = Convert.ToInt32(Console.ReadLine());

    if (numero <1 || numero >100)
    {
        Console.WriteLine("Edad incorrecta, ingrese de nuevo su edad");
    }
    else
    {
        Console.WriteLine("Edad correcta");
    }
}while (numero <1 || numero >100);
