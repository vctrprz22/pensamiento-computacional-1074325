﻿// Este es el codigo utilizando el if
Console.WriteLine("Ingrese la hora");
int hora = Convert.ToInt32(Console.ReadLine());
{
    if ( hora >= 0 && hora <= 11) 
    {
        Console.WriteLine("Buenos dias");
    }
    else if (hora >= 12 && hora <= 18)
    {
        Console.WriteLine("Buenas tardes");
    }
    else if (hora >= 19 && hora <= 23)
    {
        Console.WriteLine("Buenas noches");
    }else
    {
        Console.WriteLine("Hora no valida");
    }
}
/* usando case , no me funciono y e tiraba error, lo intente solucionar y no me dejaba
por eso lo hize con if pero aun asi le dejo el codigo con case
switch (hora)
Case 1: hora >= 0 && hora <= 11
    console.writeline("Buenos dias")
    break;
case 2: hora >= 12 && hora <= 18
    console.writeline("Buenas tardes")
    break;
case 3: hora >= 19 && hora <= 23
    console.writeline("buenas noches")
    break;
default 
    console.writeline("hora no valida")
    break
    el error que me tiraba era despues de poner los : despues del case me tiraba error intente utlizar '' Parta cerrar todo como me lo sugeria , pero seguia sin funcionar
*/ 