﻿Console.WriteLine("Ingrese un numero entre 0 y 50");
Random generador = new Random();
int aleatorio = generador.Next(0, 51);
while(true)
{
try
{ 
    int numero = Convert.ToInt32(Console.ReadLine());
    if (numero < 0 || numero > 50)
    {
        Console.WriteLine("El numero debe ser mayor a 0 y menor a 50");
    }
    else
    {
        if (numero == aleatorio)
        {
            Console.WriteLine("Felicidades n has adivinado el numero");
            break;
        }
        else if (numero < aleatorio)
        {
            Console.WriteLine("El numero que ingresastes es menor al numero aleatorio");
        }
        else
        {
            Console.WriteLine("El numero que ingresastes es mayor al numero aleatorio");
        }
    }
}
catch (System.Exception)
{
    Console.WriteLine("Ingrese un numero valido ");
    throw;
}
}

