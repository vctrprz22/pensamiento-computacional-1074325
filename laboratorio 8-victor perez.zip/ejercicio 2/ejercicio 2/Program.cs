﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Ingrese su nombre completo");
string nombre;
nombre = Console.ReadLine();
Console.WriteLine("ahora ingrese su altura en metros");
double altura;
altura = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("ingrese su edad");
int edad;
edad = Convert.ToInt16(Console.ReadLine() );
Console.WriteLine("Ingrese la inicial de su mascota");
char inicial;
inicial  = Convert.ToChar(Console.ReadLine());
Console.WriteLine(nombre);
Console.WriteLine(altura);
Console.WriteLine(edad);
Console.WriteLine(inicial);